<?php $__env->startSection('konten'); ?>       
    <!-- Content Header (Page header) -->
    <section>
    <div class="container ">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <br>
            <h2 class="m-0 text-dark"><strong>Edit Kader</strong></h2></br>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-primary card-outline">
                <form role="form" action="<?php echo e(route('updateKader', $kader->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                      <input type="hidden" name="id" value="<?php echo e($kader->id); ?>"> <br/>
                      <div class="form-group">
                        <label for="name"><strong>Nama User</strong></label></br>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($kader->name); ?>">
                      </div>
                      <div class="form-group">
                        <label for="jenis_kelamin">Jenis Kelamin</label>
                        <div class="d-flex">
                            <div class="custom-control custom-radio mr-3">
                            <input class="custom-control-input" type="radio" id="laki-laki" name="jenis_kelamin" value="Laki-laki" <?php echo e($kader->jenis_kelamin == 'Laki-laki' ? 'checked' : ''); ?>>
                            <label for="laki-laki" class="custom-control-label">Laki - Laki</label>
                            </div>
                            <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="perempuan" name="jenis_kelamin" value="Perempuan" <?php echo e($kader->jenis_kelamin == 'Perempuan' ? 'checked' : ''); ?>>
                            <label for="perempuan" class="custom-control-label">Perempuan</label>
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="alamat"><strong>Alamat<strong></label><br>
                          <textarea name="alamat" id="alamat" class="form-control"  value="<?php echo e($kader->alamat); ?>"><?php echo e($kader->alamat); ?></textarea>
                      </div>
                      <div class="form-group">
                        <label for="posyandu"><strong>Posyandu</strong></label>
                        <select class="form-control select2bs4" name="posyandu" id="posyandu" style="width: 100%;" required><br>
                        <?php $__currentLoopData = $posyandu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id_posyandu); ?>" <?php echo e($kader->id_posyandu == $item->id_posyandu ? 'selected' : ''); ?>><?php echo e($item->nama_posyandu); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <!-- /.card-body -->
    
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary mr-1">Submit</button>
                      <a href="<?php echo e(route('kader')); ?>" class="btn btn-default">Cancel</a>
                    </div>
                  </form>
            </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
      </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/operator/kader/edit.blade.php ENDPATH**/ ?>