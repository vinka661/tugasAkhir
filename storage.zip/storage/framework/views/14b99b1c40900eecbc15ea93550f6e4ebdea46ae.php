<head>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css">
</head>

<?php $__env->startSection('konten'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">HASIL PERKEMBANGAN</h1>
        <!-- DataTales Example -->
        <?php $__currentLoopData = $hasilPerkembangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-body">
            <div class="card" style="width: 50rem; background: #A7C0EA; color: black; padding-left: 30px; padding-top: 10px;">
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-sm-3">
                            <h6 class="mb-0">Nama</h6>
                        </div>
                        <dd class="col-sm-8"><?php echo e($data->nama_bayi); ?></dd>
                    </div>
                    <div class="row mb-3">
                        <div class="col-sm-3">
                            <h6 class="mb-0">Jenis Kelamin</h6>
                        </div>
                        <dd class="col-sm-8"><?php echo e($data->jk); ?></dd>
                    </div>
                    <div class="row mb-3">
                        <div class="col-sm-3">
                            <h6 class="mb-0">Tanggal Timbang</h6>
                        </div>
                        <dd class="col-sm-8"><?php echo e($data->tgl_timbang); ?></dd>
                    </div>
                    <div class="row mb-3">
                        <div class="col-sm-3">
                            <h6 class="mb-0">Status Gizi</h6>
                        </div>
                        <dd class="col-sm-8"><?php echo e($data->status_gizi); ?></dd>
                    </div>
                </div>
                <div class="col card-header text-right" style="background: #A7C0EA;">
                    <a href="<?php echo e(route('showKms', $data->id_bb)); ?>" class=" btn btn-primary" data-toggle="tooltip"><i class="fas fa-info"></i> Lihat KMS</a>
                </div>
                <div class="modal fade" id="pesan" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3>STATUS GIZI</h3>
                            </div>
                            <div class="modal-body">
                                    <div class="card-body">
                                        <p><?php echo e($data->status_gizi); ?></p>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    <!-- End of Main Content -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/ibuBayi/hasilPerkembangan/index.blade.php ENDPATH**/ ?>