<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DIGITASI KMS || POSYANDU</title>
     <!-- Font Awesome Icons -->
     <link rel="stylesheet" href="<?php echo e(url('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="../../../assets/favicon2.ico" />
    <!-- Custom fonts for this template-->
    <link href="../../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="../../../css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="../../../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(url('../../../assets/select/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('../../../assets/select/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
    <?php
        $id = str_replace('@gmail.com', '', Auth::user()->email);;
    ?>
        <!-- Sidebar -->
     <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <?php echo $__env->yieldContent('konten'); ?>
                
                <!-- /.container-fluid -->

         
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- End of Footer -->

       
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Logout!</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Anda yakin ingin keluar?</div>
                <div class="modal-footer">
                    <a class="btn btn-primary" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                    <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../../vendor/jquery/jquery.min.js"></script>
            <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

            <!-- Core plugin JavaScript-->
            <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

            <!-- Custom scripts for all pages-->
            <script src="../../js/sb-admin-2.min.js"></script>

            <!-- Page level plugins -->
            <script src="../../vendor/chart.js/Chart.min.js"></script>

            <!-- Page level custom scripts -->
            
            

            <!-- jQuery -->
            <script src="<?php echo e(url('assets/select/jquery/jquery.min.js')); ?>"></script>
            <!-- Select2 -->
            <script src="<?php echo e(url('assets/select/select2/js/select2.full.min.js')); ?>"></script>
            <!-- Page script -->
            <script>
                $(function() {
                    //Initialize Select2 Elements
                    $('.select2').select2()

                    //Initialize Select2 Elements
                    $('.select2bs4').select2({
                        theme: 'bootstrap4'
                    })
                })
            </script>
            <script>
                $(document).ready(function() {
                    $('#example').DataTable({
                        dom: 'Bfrtip',
                        buttons: [
                            'copy', 'csv', 'excel', 'pdf', 'print'
                        ]
                    });
                });
            </script>
            <script>
                function myFunction() {
                    var button = document.getElementById("bfinish");
                    var button1 = document.getElementById('bupdate');
                    var ket = document.getElementById('ket_progres');
                    var tgl = document.getElementById('datepicker');

                    ket.disabled = true;
                    tgl.disabled = true;
                    button.disabled = true;
                    button1.disabled = true;
                }
            </script>
            <script>
                $(document).ready(function () {
                    $('#akun_id').on('change', function () {
                        var id = $(this).val();
                        $.ajax({
                        type: 'get',
                        url: "<?php echo e(url('nik_akun')); ?>"+"/"+ id,
                        dataType: 'json',
                        success: function (data) {
                            var temp = [];
                            $.each(data, function (key, value) {
                                temp.push({
                                    v: value,
                                    k: key
                                });
                            });
                            $('#nama_ibu').val(temp[0].v);
                            // $("#loading").show();
                        },
                        error: function (data) {
                            console.log('Error:', data);
                        }
                    });
                });
            });
            </script>
            <!-- Page level plugins -->
            <script src="../../vendor/datatables/jquery.dataTables.min.js"></script>
            <script src="../../vendor/datatables/dataTables.bootstrap4.min.js"></script>

            <!-- Page level custom scripts -->
            <script src="../../js/demo/datatables-demo.js"></script>
            <?php echo $__env->yieldContent('java'); ?>
</body>

</html><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/layout/master.blade.php ENDPATH**/ ?>