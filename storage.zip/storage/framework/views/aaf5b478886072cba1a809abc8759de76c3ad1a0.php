<?php echo e($slot); ?>

<?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>