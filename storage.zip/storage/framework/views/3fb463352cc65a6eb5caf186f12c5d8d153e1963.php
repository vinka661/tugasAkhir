<?php $__env->startSection('konten'); ?>
    <div class="container">
        <div class="main-body">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex flex-column align-items-center text-center">
                                <div class="mt-3">
                                    <h4>Photo</h4>
                                </div>

                                <?php if(Auth::user()->photo == null): ?>
                                    <img src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="Admin"
                                        class="rounded-circle p-1 bg-primary" width="170">
                                <?php else: ?>
                                    <img src="<?php echo e(url('img/upload/avatar/' . $user->photo)); ?>" alt="Admin"
                                        class="rounded-circle p-1 bg-primary" width="170">
                                <?php endif; ?>

                                <br><label>Ganti Foto</label>

                            </div>
                            <form enctype="multipart/form-data" action="/edit-profilIbu" method="POST">

                                <input type="file" name="avatar">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <div class="col  text-right">
                                    <input type="submit" value="Simpan" class="btn btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                        <?php $__currentLoopData = $namabayi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($data->user->id == Auth::user()->id): ?>
                            <div class="row mb-3">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Nama Bayi</h6>
                                </div>
                                <dd class="col-sm-8"><?php echo e($data->nama_bayi); ?></dd>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mb-3">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Name Lengkap</h6>
                                </div>
                                <dd class="col-sm-8"><?php echo e($user->name); ?></dd>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Jenis Kelamin</h6>
                                </div>
                                <dd class="col-sm-8">
                                    <?php if($user->jenis_kelamin == 'Laki-laki'): ?>
                                        Laki - Laki
                                    <?php elseif($user->jenis_kelamin == 'Perempuan'): ?>
                                        Perempuan
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </dd>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Email</h6>
                                </div>
                                <dd class="col-sm-8"><?php echo e($user->email); ?></dd>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Alamat</h6>
                                </div>
                                <dd class="col-sm-8">
                                    <?php if($user->alamat == NULL): ?>
                                        -
                                    <?php else: ?>
                                        <?php echo e($user->alamat); ?>

                                    <?php endif; ?>
                                </dd>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Nama Posyandu</h6>
                                </div>
                                <dd class="col-sm-8">
                                    <?php echo e(!empty($user->posyandu) ? $user->posyandu->nama_posyandu:''); ?>

                                </dd>
                            </div>
                            <div class="col  text-right">
                                <a href="<?php echo e(route('userIbu.profile.edit', Auth::user()->id)); ?>"
                                    class="btn btn-primary">Edit</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/profile/profileIbu.blade.php ENDPATH**/ ?>