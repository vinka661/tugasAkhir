<?php $__env->startSection('konten'); ?>
    <!-- Content Header (Page header) -->
    <section>
        <div class="container ">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h2 class="m-0 text-dark"><strong>Timbang Bayi Balita</strong></h2></br>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card card-primary card-outline">
                                <form role="form" action="" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="nama_bayi"><strong>Nama Bayi/Balita</strong></label><br>
                                            <input type="text" class="form-control" id="nama_bayi" name="nama_bayi" value="<?php echo e($bayiBalita->nama_bayi); ?>" disabled>
                                        </div>
                                        <div class="form-group">
                                            <label for="jenis_kelamin"><strong>Jenis Kelamin</strong></label>
                                            <input type="text" class="form-control" required="jenis_kelamin" id="jenis_kelamintanggal"
                                                name="jenis_kelamin" value="<?php echo e($bayiBalita->jk); ?>" disabled>
                                        </div>
                                        <div class="form-group">
                                            <label for="umur"><strong>Umur (Bulan)</strong></label>
                                            <input type="text" class="form-control" required="required" id="umur"
                                                name="umur" value="<?php echo e($bayiBalita->umur); ?>" disabled>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->
                </div><!-- /.container-fluid -->
            </div> <br>
            <div class="container-fluid">
                <h1 class="h3 mb-2 text-gray-800">Data Timbang Bayi/Balita</h1>
                <?php
                    $id = Auth::id();
                ?>
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <?php if($canAdd): ?>
                            <a href="<?php echo e(url('timbang/createTimbang/' . $bayiBalita->id_bb . '/' . $id)); ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-plus"></i> Tambah Data Timbang
                            </a>
                        <?php else: ?>
                            <button type="button" class="btn btn-primary btn-sm" disabled>
                                <i class="fas fa-plus"></i> Tambah Data Timbang
                            </button>
                        <?php endif; ?>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Kader</th>
                                        <th>Tanggal Timbang</th>
                                        <th>BB</th>
                                        <th>TB</th>
                                        <th>LK</th>
                                        <th>Status Gizi</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $timbang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data->user->id == Auth::user()->id): ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($data->user->name); ?></td>
                                        <td><?php echo e($data->tgl_timbang); ?></td>
                                        <td><?php echo e($data->berat_badan); ?></td>
                                        <td>
                                            <?php if($data->tinggi_badan == NULL): ?>
                                                -
                                            <?php else: ?>
                                                <?php echo e($data->tinggi_badan); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($data->lingkar_kepala == NULL): ?>
                                                -
                                            <?php else: ?>
                                                <?php echo e($data->lingkar_kepala); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($data->status_gizi); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('editTimbang', $data->id_timbang)); ?>"><button  class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</button></a>
                                            <a href="<?php echo e(route('deleteTimbang', $data->id_timbang)); ?>"><button  class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Hapus</button></a>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/kader/timbang/detail.blade.php ENDPATH**/ ?>