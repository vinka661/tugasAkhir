<?php $__env->startSection('konten'); ?>
    <?php
    $id = str_replace('@gmail.com', '', Auth::user()->email);
    ?>
    <div class="content-wrapper">
        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-primary card-outline">
                            <form action="<?php echo e(route('userIbu.profile.update', $user->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <input type="text" class="form-control" id="id" name="id" value="<?php echo e($user->id); ?>"
                                        hidden>
                                    <div class="form-group">
                                        <label for="nama">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                            placeholder="Nama Lengkap" value="<?php echo e($user->name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="jenis_kelamin">Jenis Kelamin</label>
                                        <div class="d-flex">
                                            <div class="custom-control custom-radio mr-3">
                                                <input class="custom-control-input" type="radio" id="laki-laki"
                                                    name="jenis_kelamin" value="Laki-laki"
                                                    <?php echo e($user->jenis_kelamin == 'Laki-laki' ? 'checked' : ''); ?>>
                                                <label for="laki-laki" class="custom-control-label">Laki - Laki</label>
                                            </div>
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" id="perempuan"
                                                    name="jenis_kelamin" value="Perempuan"
                                                    <?php echo e($user->jenis_kelamin == 'Perempuan' ? 'checked' : ''); ?>>
                                                <label for="perempuan" class="custom-control-label">Perempuan</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="email"><strong>Email</strong></label></br>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="alamat">Alamat</label>
                                        <textarea class="form-control" name="alamat" id="alamat" rows="3"><?php echo e($user->alamat); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="posyandu"><strong>Nama Posyandu</strong></label>
                                        <select class="form-control select2bs4" name="posyandu" id="posyandu" style="width: 100%;" required><br>
                                        <?php $__currentLoopData = $posyandu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id_posyandu); ?>" <?php echo e($user->id_posyandu == $item->id_posyandu ? 'selected' : ''); ?>><?php echo e($item->nama_posyandu); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary mr-1">Submit</button>
                            <a href="<?php echo e(route('userIbu.profile', Auth::user()->id)); ?>" class="btn btn-default">Cancel</a>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/profile/editProfileIbu.blade.php ENDPATH**/ ?>