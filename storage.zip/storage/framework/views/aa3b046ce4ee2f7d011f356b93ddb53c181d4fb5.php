<ul class="navbar-nav bg-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon ">
                    <i class="fas fa-laptop-medical"></i>
                </div>
                <div class="sidebar-brand-text mx-3">SIMDIG KMS</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operator-plkb')): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route ('berandaOperator')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">
            <div class="sidebar-heading">
                Data Master
            </div>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('posyandu')); ?>">
                    <i class="fas fa-book-medical"></i>
                    <span>Data Posyandu</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('kader')); ?>">
                    <i class="fas fa-user"></i>
                    <span>Data Kader</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('bayiBalita')); ?>">
                    <i class="fas fa-baby"></i>
                    <span>Data Bayi/Balita</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('bidan')); ?>">
                    <i class="fas fa-user-nurse"></i>
                    <span>Data Bidan Desa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('user')); ?>">
                    <i class="fas fa-user"></i>
                    <span>Data User</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('laporan')); ?>">
                    <i class="fas fa-book"></i>
                    <span>Data Laporan</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kepala-plkb')): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route ('berandaOperator')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">
            <div class="sidebar-heading">
                 
            </div>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.profile', Auth::user()->id)); ?>">
                    <i class="fas fa-user"></i>
                    <span>Data Diri</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('laporan')); ?>">
                    <i class="fas fa-book"></i>
                    <span>Data Laporan</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ibu-bayi')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('userIbu.profile', Auth::user()->id)); ?>">
                    <i class="fas fa-user"></i>
                    <span>Data Diri</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('hasilPerkembangan')); ?>">
                    <i class="fas fa-chart-bar"></i>
                    <span>Hasil Perkembangan</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('konsultasiIbu')); ?>">
                    <i class="fas fa-user"></i>
                    <span>Konsultasi Online</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kader')): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route ('berandaKader')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">
            <div class="sidebar-heading">
                 
            </div>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.profile', Auth::user()->id)); ?>">
                    <i class="fas fa-user"></i>
                    <span>Data Diri</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('timbangbayiBalita')); ?>">
                    <i class="fas fa-baby"></i>
                    <span>Data Timbang Bayi/Balita</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('penyuluhanKader')); ?>">
                    <i class="fas fa-users"></i>
                    <span>Penyuluhan</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('laporan')); ?>">
                    <i class="fas fa-book"></i>
                    <span>Data Laporan</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bidan-desa')): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route ('berandaBidan')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">
            <div class="sidebar-heading">
                 
            </div>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.profile', Auth::user()->id)); ?>">
                    <i class="fas fa-user"></i>
                    <span>Data Diri</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('imunisasiDanvitaminA')); ?>">
                    <i class="fas fa-briefcase-medical"></i>
                    <span>Data Imunisasi&VitaminA</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('jenisVaksinImunisasi')); ?>">
                    <i class="fas fa-vials"></i>
                    <span>Jenis Vaksin Imunisasi</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('konsultasi')); ?>">
                    <i class="fas fa-user"></i>
                    <span>Konsultasi Online</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('penyuluhan')); ?>">
                    <i class="fas fa-calendar"></i>
                    <span>Jadwal Penyuluhan</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('jadwalPosyandu')); ?>">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Jadwal Posyandu</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route ('laporan')); ?>">
                    <i class="fas fa-book"></i>
                    <span>Data Laporan</span>
                </a>
            </li>
            <?php endif; ?>
</ul><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>