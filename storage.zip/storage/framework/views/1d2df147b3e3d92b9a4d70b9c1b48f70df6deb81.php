<head>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css">
</head>

<?php $__env->startSection('konten'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">KONSULTASI ONLINE</h1>
        <!-- DataTales Example -->
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php
            $id = Auth::id();
        ?>
        <div class="card-body">
            <div class="card" style="width: 50rem; background: #A7C0EA; color: black;">
                <div class="card-body">
                    <h4 class="card-title"> Anda bisa memulai konsultasi online mengenai perkembangan gizi bayi/balita
                        Anda.</h4>
                </div>
                <div class="col card-header text-left" style="background: #A7C0EA;">
                    <a href="<?php echo e(url('konsultasiIbu/createKonsultasi/'. $id  )); ?>" class="btn btn-primary" style="background: #F08080;"><i class="fas fa-comment"></i> Mulai Konsultasi </a>
                </div>
            </div>
        </div>
        
        <h1 class="h3 mb-2 text-gray-800">Riwayat Konsultasi</h1>
        <div class="accordion" id="accordionExample">
            <?php $__currentLoopData = $konsultasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->user->id == Auth::user()->id): ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <div class="circle-icon"> <i class="fa fa-question"></i> </div>
                                <span><?php echo e($data->konsul); ?></span>
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body"><strong>SOLUSI : 
                                <?php if($data->solusi == NULL): ?>
                                    (belum ada tanggapan)
                                <?php else: ?>
                                    <?php echo e($data->solusi); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
        </script>
    </div>
    <!-- /.container-fluid -->
    <!-- End of Main Content -->
    <div class="modal fade" id="pesan" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>FORM KONSULTASI ONLINE</h3>
                </div>
                <div class="modal-body">
                    <form role="form" action="<?php echo e(route('storeKonsultasi')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="nama_ibu"><strong>Nama Ibu</strong></label></br>
                                <input type="text" class="form-control" id="nama_ibu" name="nama_ibu"
                                    placeholder="Masukkan Nama Ibu Bayi/Balita">
                            </div>
                            <div class="form-group">
                                <label for="konsul"><strong>Konsul<strong></label><br>
                                <textarea name="konsul" id="konsul" class="form-control" rows="5" placeholder="Masukkan Konsultasi"
                                    required></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary mr-1">Submit</button>
                            <button class="btn btn-primary mr-1" data-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    </div>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/ibuBayi/konsultasi/index.blade.php ENDPATH**/ ?>