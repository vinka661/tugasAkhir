<?php $__env->startSection('konten'); ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">DATA LAPORAN</h1>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <?php if($setuju): ?>
                                <!-- <input id="search" type="text" name="search"> -->
                                <!--  -->
                                <!--  -->
                                <a href="<?php echo e(route('cetak_pdf')); ?>" target="_blank" class="btn btn-success btn-sm"><i
                                        class="fas fa-print"></i> Cetak Pdf</a>
                                <a href="<?php echo e(route('exportLaporan')); ?>" target="_blank" class="btn btn-success btn-sm"><i
                                        class="fas fa-print"></i> Cetak Excel</a>
                            <?php else: ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kepala-plkb')): ?>
                                    <a href="<?php echo e(route('laporansetuju')); ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i>
                                        Setujui</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Tanggal</th>
                                            <th>Posyandu</th>
                                            <th>Kader</th>
                                            <th>Bayi/Balita</th>
                                            <th>BB</th>
                                            <th>TB</th>
                                            <th>LK</th>
                                            <th>Status Gizi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($data->tgl_timbang); ?></td>
                                            <td><?php echo e($data->nama_posyandu); ?></td>
                                            <td><?php echo e($data->name); ?></td>
                                            <td><?php echo e($data->nama_bayi); ?></td>
                                            <td><?php echo e($data->berat_badan); ?></td>
                                            <td><?php echo e($data->tinggi_badan); ?></td>
                                            <td>
                                                <?php if($data->lingkar_kepala == NULL): ?>
                                                    -
                                                <?php else: ?>
                                                    <?php echo e($data->lingkar_kepala); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($data->status_gizi); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                  
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/laporan/index.blade.php ENDPATH**/ ?>