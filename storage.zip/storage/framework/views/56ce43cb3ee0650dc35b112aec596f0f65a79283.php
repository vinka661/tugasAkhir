<?php $__env->startSection('konten'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">JADWAL PENYULUHAN</h1>
        <!-- DataTales Example -->
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <?php $__currentLoopData = $penyuluhanKader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->user->id == Auth::user()->id): ?>
                    <div class="card" style="width: 60rem;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-calendar-alt"></i> Tanggal : <?php echo e($data->tanggal); ?>

                            </h5>
                            <p class="card-text"><i class="fas fa-calendar-day"></i> Hari : <?php echo e($data->hari); ?></p>
                            <p class="card-text"><i class="fas fa-book-medical"></i> Materi : <?php echo e($data->materi); ?></p>
                        </div>
                        <div class="col card-header text-right">
                            <a href="<?php echo e(route('UploadMateriPenyuluhan', $data->id_penyuluhan)); ?>">
                                <button class="btn btn-primary"><i class="fas fa-file-upload"></i> Upload Materi</button> 
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/kader/penyuluhan/index.blade.php ENDPATH**/ ?>