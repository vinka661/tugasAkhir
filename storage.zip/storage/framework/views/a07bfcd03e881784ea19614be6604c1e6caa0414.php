<?php $__env->startSection('konten'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Data Diri</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-primary card-outline">
              <div class="card-body">
                <div class="row">
                  <div class="col-lg-2">
                    <?php if(Auth::user()->photo == null): ?>
                      <img class="img-circle elevation-2" src="<?php echo e(url('../img/user2-160x160.jpg')); ?>" width="150px" height="150px" alt="User Avatar">  
                    <?php else: ?>
                      <img class="img-circle elevation-2" src="<?php echo e(Auth::user()->photo); ?>" width="150px" height="150px" alt="User Avatar">
                    <?php endif; ?>
                  </div>
                  <div class="col-lg-10">
                    <dl class="row">
                      <dt class="col-sm-4">Nama Lengkap</dt>
                      <dd class="col-sm-8"><?php echo e($kepala->name); ?></dd>
                      <dt class="col-sm-4">Jenis Kelamin</dt>
                      <dd class="col-sm-8">                    
                        <?php if($kepala->jenis_kelamin == 'L'): ?>
                            Laki - Laki
                        <?php else: ?>
                            Perempuan
                        <?php endif; ?>
                      </dd>
                      <dt class="col-sm-4">Alamat</dt>
                        <dd class="col-sm-8"><?php echo e($kepala->alamat); ?></dd>
                      </dl>
                  </div>
                </div>
                <div class="col  text-right">
                <a href="<?php echo e(route('editDataKepala', $kepala->id)); ?>" class="btn btn-primary">Edit</a>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\posyandu\resources\views/kepala/dataDiri/index.blade.php ENDPATH**/ ?>